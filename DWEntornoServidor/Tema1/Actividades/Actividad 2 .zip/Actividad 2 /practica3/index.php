<html> <head>
<meta charset= "UTF-8">
<title></title>
</head> <body>
<?php
echo '<h1> Manejo de cadenas</h1>';
echo '<h3> Ejemplo 2</h3>';
print ("<UL>\n");
    print ("<LI>uno</LI>\n");   
    print ("<LI>dos</LI>\n");   
    print ("<LI>tres</LI>\n");   
    print ("<LI>cuatro</LI>\n");   
    print ("<LI>cinco</LI>\n");   
print ("</UL>\n");

?>
</body> </html>