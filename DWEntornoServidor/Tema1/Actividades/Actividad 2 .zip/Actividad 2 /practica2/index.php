<html> <head>
<meta charset= "UTF-8">
<title></title>
</head> <body>
<?php
echo '<h1> Práctica 2</h1>';
echo '<p>Éste código HTML ha sido generado mediante instrucciones escritas en lenguaje PHP.</p>';
?>
</body> </html>